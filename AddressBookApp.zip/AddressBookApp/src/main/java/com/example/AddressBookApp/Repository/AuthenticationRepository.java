package com.example.AddressBookApp.Repository;

import com.example.AddressBookApp.model.AuthUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;
@Repository
public interface AuthenticationRepository extends JpaRepository<AuthUser, Long> {

    //Changes

    AuthUser findByEmail(String email);
    AuthUser findByResetToken(String resetToken);
}